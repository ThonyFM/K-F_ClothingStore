CREATE PROCEDURE ObtenerProductos
AS
BEGIN
    SELECT ID, NombreProducto, Genero, SegmentoEdad, TipoProducto, Color, Talla, UnidadesDisponibles, Precio, ImagenUrl, Descripcion, FechaCreacion, FechaModificacion
    FROM Producto
END
go

