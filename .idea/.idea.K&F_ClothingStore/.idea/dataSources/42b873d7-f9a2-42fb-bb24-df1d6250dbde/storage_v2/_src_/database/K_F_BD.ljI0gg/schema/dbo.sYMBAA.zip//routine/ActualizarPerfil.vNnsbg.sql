-- Procedimiento para actualizar los datos del perfil
    CREATE PROCEDURE ActualizarPerfil
        @ClienteID INT,
        @Nombre1 NVARCHAR(50),
        @Nombre2 NVARCHAR(50),
        @Apellido1 NVARCHAR(50),
        @Apellido2 NVARCHAR(50),
        @Telefono NVARCHAR(15),
        @FechaNacimiento DATE,
        @Genero NVARCHAR(50),
        @DireccionID INT,
        @Ciudad NVARCHAR(50),
        @Estado NVARCHAR(50),
        @CodigoPostal NVARCHAR(20),
        @Pais NVARCHAR(50),
        @TipoDireccion NVARCHAR(20)
    AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE Persona
        SET Nombre1 = @Nombre1,
            Nombre2 = @Nombre2,
            Apellido1 = @Apellido1,
            Apellido2 = @Apellido2,
            Telefono = @Telefono,
            FechaNacimiento = @FechaNacimiento,
            Genero = @Genero,
            FechaModificacion = GETDATE()
        WHERE ID = @ClienteID;

        UPDATE Direccion
        SET Ciudad = @Ciudad,
            Estado = @Estado,
            CodigoPostal = @CodigoPostal,
            Pais = @Pais,
            TipoDireccion = @TipoDireccion,
            FechaModificacion = GETDATE()
        WHERE ID = @DireccionID;
    END;
go

