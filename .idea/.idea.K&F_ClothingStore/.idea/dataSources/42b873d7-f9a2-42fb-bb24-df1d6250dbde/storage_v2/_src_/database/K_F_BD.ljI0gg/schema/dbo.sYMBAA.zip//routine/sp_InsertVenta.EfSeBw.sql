
CREATE PROCEDURE sp_InsertVenta
    @EmpleadoID INT,
    @ClienteID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Total DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Venta (EmpleadoID, ClienteID, ProductoID, Cantidad, Total)
    VALUES (@EmpleadoID, @ClienteID, @ProductoID, @Cantidad, @Total);
END;
go

