CREATE PROCEDURE sp_ObtenerDevoluciones
AS
BEGIN
    SELECT
        D.ID,
        D.FacturaID,
        D.DetalleFacturaID,
        D.ProductoID,
        P.NombreProducto,
        D.Cantidad,
        D.Motivo,
        D.Estado,
        D.FechaDevolucion,
        D.CreadoPor,
        D.FechaCreacion
    FROM Devolucion D
             INNER JOIN Producto P ON D.ProductoID = P.ID
    ORDER BY D.FechaDevolucion DESC;
END
go

