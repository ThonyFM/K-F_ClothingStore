
CREATE PROCEDURE sp_DeleteVenta
    @VentaID INT
AS
BEGIN
    DELETE FROM Venta WHERE VentaID = @VentaID;
END;
go

