CREATE   PROCEDURE sp_ObtenerPerfilUsuario
@UsuarioID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.ID AS UsuarioID,
        u.NombreUsuario,
        u.ContrasenaHash,
        u.Email AS UsuarioEmail,
        u.Rol,
        u.Estado,

        p.ID AS PersonaID,
        p.Nombre1,
        p.Nombre2,
        p.Apellido1,
        p.Apellido2,
        p.Telefono,
        p.Email AS PersonaEmail,
        p.Genero,
        p.DireccionID,

        d.ID AS DireccionID,
        d.Ciudad,
        d.Estado AS EstadoDireccion,
        d.CodigoPostal,
        d.Pais,
        d.TipoDireccion,

        c.ID AS ClienteID,
        c.PersonaID AS ClientePersonaID

    FROM Usuario u
             INNER JOIN Persona p ON u.Email = p.Email
             LEFT JOIN Cliente c ON p.ID = c.PersonaID
             LEFT JOIN Direccion d ON p.DireccionID = d.ID
    WHERE u.ID = @UsuarioID;
END
go

