
CREATE PROCEDURE sp_DeleteDireccion
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Verificar si la dirección está en uso
    IF EXISTS (SELECT 1 FROM Persona WHERE DireccionID = @ID)
    BEGIN
        RAISERROR('No se puede eliminar la dirección porque está en uso.', 16, 1);
        RETURN;
    END

    DELETE FROM Direccion WHERE ID = @ID;
END
go

