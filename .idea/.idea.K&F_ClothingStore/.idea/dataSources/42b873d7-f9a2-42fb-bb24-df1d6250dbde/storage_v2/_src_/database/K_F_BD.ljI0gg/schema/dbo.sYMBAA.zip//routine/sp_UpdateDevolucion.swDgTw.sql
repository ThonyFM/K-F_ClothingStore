
CREATE PROCEDURE sp_UpdateDevolucion
    @ID INT,
    @FacturaID INT,
    @DetalleFacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Motivo NVARCHAR(255),
    @Estado NVARCHAR(50),
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Devolucion
    SET FacturaID = @FacturaID, DetalleFacturaID = @DetalleFacturaID, ProductoID = @ProductoID,
        Cantidad = @Cantidad, Motivo = @Motivo, Estado = @Estado, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

