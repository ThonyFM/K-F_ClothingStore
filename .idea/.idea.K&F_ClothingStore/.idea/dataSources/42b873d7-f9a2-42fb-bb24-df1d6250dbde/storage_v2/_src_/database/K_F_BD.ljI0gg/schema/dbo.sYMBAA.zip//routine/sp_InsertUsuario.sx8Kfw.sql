
CREATE PROCEDURE sp_InsertUsuario
    @NombreUsuario NVARCHAR(50),
    @ContrasenaHash NVARCHAR(255),
    @Email NVARCHAR(255),
    @Rol NVARCHAR(50),
    @Estado NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Usuario (NombreUsuario, ContrasenaHash, Email, Rol, Estado)
    VALUES (@NombreUsuario, @ContrasenaHash, @Email, @Rol, @Estado);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

