CREATE PROCEDURE InsertarDireccion
    @Ciudad VARCHAR(50),
    @Estado VARCHAR(50),
    @CodigoPostal VARCHAR(20),
    @Pais VARCHAR(50),
    @TipoDireccion VARCHAR(20),
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Direccion (Ciudad, Estado, CodigoPostal, Pais, TipoDireccion, FechaCreacion, CreadoPor)
    VALUES (@Ciudad, @Estado, @CodigoPostal, @Pais, @TipoDireccion, GETDATE(), @CreadoPor)
END
go

