CREATE PROCEDURE sp_EliminarCarritoPorCliente
@ClienteID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM CarritoCompras
    WHERE ClienteID = @ClienteID;
END;
go

