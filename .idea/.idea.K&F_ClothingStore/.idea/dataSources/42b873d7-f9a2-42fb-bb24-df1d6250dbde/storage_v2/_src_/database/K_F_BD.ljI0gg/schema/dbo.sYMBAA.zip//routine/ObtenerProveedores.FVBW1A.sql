CREATE PROCEDURE ObtenerProveedores
AS
BEGIN
    SELECT ID, NombreEmpresa, NombreContacto, Telefono, Email, DireccionID, Estado, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Proveedor
END
go

