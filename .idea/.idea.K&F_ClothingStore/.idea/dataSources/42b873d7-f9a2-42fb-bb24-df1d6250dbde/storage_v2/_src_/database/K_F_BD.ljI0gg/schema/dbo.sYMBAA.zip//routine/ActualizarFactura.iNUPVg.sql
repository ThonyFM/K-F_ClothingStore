CREATE PROCEDURE ActualizarFactura
    @ID INT,
    @ClienteID INT,
    @Total DECIMAL(18,2),
    @MetodoPago VARCHAR(50),
    @Estado VARCHAR(50),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Factura
    SET ClienteID = @ClienteID,
        Total = @Total,
        MetodoPago = @MetodoPago,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

