CREATE PROCEDURE ActualizarDevolucion
    @ID INT,
    @FacturaID INT,
    @DetalleFacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Motivo VARCHAR(255),
    @Estado VARCHAR(50),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Devolucion
    SET FacturaID = @FacturaID,
        DetalleFacturaID = @DetalleFacturaID,
        ProductoID = @ProductoID,
        Cantidad = @Cantidad,
        Motivo = @Motivo,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

