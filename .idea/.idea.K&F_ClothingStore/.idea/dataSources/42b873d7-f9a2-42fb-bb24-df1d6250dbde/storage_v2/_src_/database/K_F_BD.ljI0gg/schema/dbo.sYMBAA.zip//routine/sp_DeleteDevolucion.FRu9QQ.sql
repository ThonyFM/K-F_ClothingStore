
CREATE PROCEDURE sp_DeleteDevolucion
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM Devolucion WHERE ID = @ID;
END
go

