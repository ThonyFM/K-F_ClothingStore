
CREATE PROCEDURE sp_UpdateEmpleado
    @ID INT,
    @Puesto NVARCHAR(100),
    @FechaContratacion DATE,
    @Salario DECIMAL(10,2),
    @Estado NVARCHAR(50),
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Empleado
    SET Puesto = @Puesto, FechaContratacion = @FechaContratacion, Salario = @Salario,
        Estado = @Estado, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

