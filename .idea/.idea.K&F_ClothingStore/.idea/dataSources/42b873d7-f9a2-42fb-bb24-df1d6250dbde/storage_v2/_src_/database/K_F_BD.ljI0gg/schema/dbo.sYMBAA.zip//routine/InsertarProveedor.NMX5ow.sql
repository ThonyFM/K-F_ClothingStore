CREATE PROCEDURE InsertarProveedor
    @NombreEmpresa VARCHAR(100),
    @NombreContacto VARCHAR(100),
    @Telefono VARCHAR(15),
    @Email VARCHAR(255),
    @DireccionID INT,
    @Estado VARCHAR(50),
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Proveedor (NombreEmpresa, NombreContacto, Telefono, Email, DireccionID, Estado, FechaCreacion, CreadoPor)
    VALUES (@NombreEmpresa, @NombreContacto, @Telefono, @Email, @DireccionID, @Estado, GETDATE(), @CreadoPor)
END
go

