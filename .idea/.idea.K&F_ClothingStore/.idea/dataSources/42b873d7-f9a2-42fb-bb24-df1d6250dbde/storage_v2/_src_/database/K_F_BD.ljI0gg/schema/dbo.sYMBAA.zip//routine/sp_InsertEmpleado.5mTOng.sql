
CREATE PROCEDURE sp_InsertEmpleado
    @PersonaID INT,
    @Puesto NVARCHAR(100),
    @FechaContratacion DATE,
    @Salario DECIMAL(10,2),
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Empleado (PersonaID, Puesto, FechaContratacion, Salario, Estado, CreadoPor)
    VALUES (@PersonaID, @Puesto, @FechaContratacion, @Salario, @Estado, @CreadoPor);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

