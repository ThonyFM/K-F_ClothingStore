
CREATE PROCEDURE sp_InsertProveedor
    @NombreEmpresa NVARCHAR(100),
    @NombreContacto NVARCHAR(100),
    @Telefono NVARCHAR(15),
    @Email NVARCHAR(255),
    @DireccionID INT,
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50)
AS
BEGIN
    INSERT INTO Proveedor (NombreEmpresa, NombreContacto, Telefono, Email, DireccionID, Estado, CreadoPor)
    VALUES (@NombreEmpresa, @NombreContacto, @Telefono, @Email, @DireccionID, @Estado, @CreadoPor);
END;
go

