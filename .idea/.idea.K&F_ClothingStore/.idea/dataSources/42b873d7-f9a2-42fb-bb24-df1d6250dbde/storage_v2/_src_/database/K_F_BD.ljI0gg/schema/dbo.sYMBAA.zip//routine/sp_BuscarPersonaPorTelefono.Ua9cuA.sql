CREATE PROCEDURE sp_BuscarPersonaPorTelefono
@Telefono NVARCHAR(15)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT *
    FROM Persona
    WHERE Telefono = @Telefono;
END;
go

