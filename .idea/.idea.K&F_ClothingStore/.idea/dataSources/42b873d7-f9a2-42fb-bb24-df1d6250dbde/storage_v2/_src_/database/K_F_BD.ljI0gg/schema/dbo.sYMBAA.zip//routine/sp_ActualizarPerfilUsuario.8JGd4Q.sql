CREATE PROCEDURE sp_ActualizarPerfilUsuario
    @UsuarioID INT,
    @NombreUsuario NVARCHAR(50),
    @Rol NVARCHAR(20),
    @PersonaID INT,
    @Nombre1 NVARCHAR(50),
    @Nombre2 NVARCHAR(50),
    @Apellido1 NVARCHAR(50),
    @Apellido2 NVARCHAR(50),
    @Telefono NVARCHAR(20),
    @Genero NVARCHAR(10),
    @PersonaEmail NVARCHAR(100),
    @DireccionID INT,
    @Ciudad NVARCHAR(50),
    @Estado NVARCHAR(50),
    @CodigoPostal NVARCHAR(20),
    @Pais NVARCHAR(50),
    @TipoDireccion NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    -- ✅ Actualiza datos de Usuario (excepto Email)
    UPDATE Usuario
    SET NombreUsuario = @NombreUsuario,
        Rol = @Rol,
        FechaModificacion = GETDATE()
    WHERE ID = @UsuarioID;

    -- ✅ Actualiza Persona
    UPDATE Persona
    SET Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        Apellido1 = @Apellido1,
        Apellido2 = @Apellido2,
        Telefono = @Telefono,
        Email = @PersonaEmail,
        Genero = @Genero,
        FechaModificacion = GETDATE()
    WHERE ID = @PersonaID;

    -- ✅ Actualiza Dirección
    UPDATE Direccion
    SET Ciudad = @Ciudad,
        Estado = @Estado,
        CodigoPostal = @CodigoPostal,
        Pais = @Pais,
        TipoDireccion = @TipoDireccion,
        FechaModificacion = GETDATE()
    WHERE ID = @DireccionID;
END;
go

