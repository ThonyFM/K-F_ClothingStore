CREATE PROCEDURE ObtenerPersonas
AS
BEGIN
    SELECT ID, Nombre1, Nombre2, Apellido1, Apellido2, DocumentoIdentidad, Telefono, Email, FechaNacimiento, Genero, DireccionID, UsuarioID, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Persona
END
go

