CREATE   PROCEDURE sp_ObtenerFacturaPorId
@ID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID,
        ClienteID,
        Total,
        MetodoPago,
        Estado,
        FechaCreacion,
        FechaModificacion,
        CreadoPor,
        ModificadoPor
    FROM Factura
    WHERE ID = @ID;
END;
go

