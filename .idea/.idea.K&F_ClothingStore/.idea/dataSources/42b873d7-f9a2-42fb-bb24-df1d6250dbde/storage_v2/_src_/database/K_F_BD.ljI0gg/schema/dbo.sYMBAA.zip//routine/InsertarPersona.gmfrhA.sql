CREATE PROCEDURE InsertarPersona
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @Apellido1 VARCHAR(50),
    @Apellido2 VARCHAR(50),
    @DocumentoIdentidad VARCHAR(20),
    @Telefono VARCHAR(15),
    @Email VARCHAR(255),
    @FechaNacimiento DATE,
    @Genero VARCHAR(50),
    @DireccionID INT,
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Persona (Nombre1, Nombre2, Apellido1, Apellido2, DocumentoIdentidad, Telefono, Email, FechaNacimiento, Genero, DireccionID, FechaCreacion, CreadoPor)
    VALUES (@Nombre1, @Nombre2, @Apellido1, @Apellido2, @DocumentoIdentidad, @Telefono, @Email, @FechaNacimiento, @Genero, @DireccionID, GETDATE(), @CreadoPor)
END
go

