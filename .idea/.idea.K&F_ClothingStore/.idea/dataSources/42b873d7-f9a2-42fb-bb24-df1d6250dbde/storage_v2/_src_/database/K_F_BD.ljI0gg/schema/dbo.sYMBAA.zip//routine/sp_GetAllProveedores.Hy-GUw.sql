
CREATE PROCEDURE sp_GetAllProveedores
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Proveedor;
END
go

