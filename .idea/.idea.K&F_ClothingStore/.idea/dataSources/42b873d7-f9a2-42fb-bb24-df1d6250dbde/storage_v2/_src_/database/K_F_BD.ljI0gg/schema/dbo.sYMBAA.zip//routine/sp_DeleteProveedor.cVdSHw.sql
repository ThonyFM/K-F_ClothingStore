
CREATE PROCEDURE sp_DeleteProveedor
    @ID INT
AS
BEGIN
    DELETE FROM Proveedor WHERE ID = @ID;
END;
go

