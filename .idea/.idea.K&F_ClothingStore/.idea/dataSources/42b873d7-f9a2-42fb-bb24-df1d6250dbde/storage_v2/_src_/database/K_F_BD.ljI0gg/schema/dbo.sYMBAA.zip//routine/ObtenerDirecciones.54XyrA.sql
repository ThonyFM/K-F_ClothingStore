CREATE PROCEDURE ObtenerDirecciones
AS
BEGIN
    SELECT ID, Ciudad, Estado, CodigoPostal, Pais, TipoDireccion, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Direccion
END
go

