
CREATE PROCEDURE sp_UpdateVenta
    @VentaID INT,
    @EmpleadoID INT,
    @ClienteID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Total DECIMAL(10,2)
AS
BEGIN
    UPDATE Venta
    SET EmpleadoID = @EmpleadoID, ClienteID = @ClienteID, ProductoID = @ProductoID, Cantidad = @Cantidad, Total = @Total
    WHERE VentaID = @VentaID;
END;
go

