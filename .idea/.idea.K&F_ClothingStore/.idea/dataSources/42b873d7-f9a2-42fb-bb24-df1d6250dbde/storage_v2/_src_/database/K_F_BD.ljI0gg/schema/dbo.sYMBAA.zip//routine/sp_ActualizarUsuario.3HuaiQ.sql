CREATE PROCEDURE sp_ActualizarUsuario
    @ID INT,
    @Correo NVARCHAR(100),
    @Clave NVARCHAR(100)
AS
BEGIN
    UPDATE Usuario
    SET Email = @Correo, ContrasenaHash = @Clave
    WHERE ID = @ID;
END;
go

