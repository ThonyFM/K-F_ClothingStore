CREATE PROCEDURE InsertarDevolucion
    @FacturaID INT,
    @DetalleFacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Motivo VARCHAR(255),
    @Estado VARCHAR(50),
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Devolucion (FacturaID, DetalleFacturaID, ProductoID, Cantidad, Motivo, FechaDevolucion, Estado, FechaCreacion, CreadoPor)
    VALUES (@FacturaID, @DetalleFacturaID, @ProductoID, @Cantidad, @Motivo, GETDATE(), @Estado, GETDATE(), @CreadoPor)
END
go

