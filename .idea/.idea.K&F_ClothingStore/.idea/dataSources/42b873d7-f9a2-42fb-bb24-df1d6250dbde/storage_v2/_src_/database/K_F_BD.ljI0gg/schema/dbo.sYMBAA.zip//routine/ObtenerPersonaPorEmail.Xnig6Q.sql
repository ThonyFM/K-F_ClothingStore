CREATE PROCEDURE ObtenerPersonaPorEmail
@Email NVARCHAR(255)
AS
BEGIN
    SELECT *
       
    FROM
        Persona
    WHERE
        Email = @Email;
END
go

