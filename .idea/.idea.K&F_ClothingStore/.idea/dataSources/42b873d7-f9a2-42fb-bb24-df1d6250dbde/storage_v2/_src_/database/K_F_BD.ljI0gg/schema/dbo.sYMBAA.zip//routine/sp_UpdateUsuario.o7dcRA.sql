
CREATE PROCEDURE sp_UpdateUsuario
    @ID INT,
    @NombreUsuario NVARCHAR(50),
    @ContrasenaHash NVARCHAR(255),
    @Email NVARCHAR(255),
    @Rol NVARCHAR(50),
    @Estado NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Usuario
    SET NombreUsuario = @NombreUsuario, ContrasenaHash = @ContrasenaHash, Email = @Email,
        Rol = @Rol, Estado = @Estado, FechaModificacion = GETDATE()
    WHERE ID = @ID;
END
go

