CREATE PROCEDURE sp_ActualizarCantidadCarrito
    @ClienteID INT,
    @ProductoID INT,
    @NuevaCantidad INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE CarritoCompras
    SET Cantidad = @NuevaCantidad,
        FechaModificacion = GETDATE()
    WHERE ClienteID = @ClienteID AND ProductoID = @ProductoID;
END;
go

