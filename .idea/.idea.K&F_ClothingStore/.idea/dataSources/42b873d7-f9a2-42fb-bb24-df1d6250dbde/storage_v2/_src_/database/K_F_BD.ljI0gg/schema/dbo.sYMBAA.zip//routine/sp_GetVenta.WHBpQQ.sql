
CREATE PROCEDURE sp_GetVenta
    @VentaID INT
AS
BEGIN
    SELECT * FROM Venta WHERE VentaID = @VentaID;
END;
go

