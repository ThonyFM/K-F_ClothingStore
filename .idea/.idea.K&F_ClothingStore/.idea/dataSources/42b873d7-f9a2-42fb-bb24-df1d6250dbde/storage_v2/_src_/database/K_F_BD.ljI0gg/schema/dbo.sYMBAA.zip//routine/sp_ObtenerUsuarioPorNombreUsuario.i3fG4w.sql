CREATE PROCEDURE sp_ObtenerUsuarioPorNombreUsuario
@NombreUsuario NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT ID, NombreUsuario, ContrasenaHash, Email, Rol, Estado, FechaCreacion, FechaModificacion
    FROM Usuario
    WHERE NombreUsuario = @NombreUsuario;
END;
go

