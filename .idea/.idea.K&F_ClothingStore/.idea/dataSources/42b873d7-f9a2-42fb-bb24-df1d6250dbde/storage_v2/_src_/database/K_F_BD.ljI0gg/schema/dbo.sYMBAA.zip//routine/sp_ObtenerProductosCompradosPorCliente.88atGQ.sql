CREATE   PROCEDURE sp_ObtenerProductosCompradosPorCliente
@ClienteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        DF.ID, -- ID del detalle
        DF.FacturaID,
        DF.ProductoID,
        DF.Cantidad,
        DF.PrecioUnitario,
        DF.Subtotal,
        P.NombreProducto,
        F.FechaCreacion AS FechaFactura
    FROM DetalleFactura DF
             INNER JOIN Factura F ON DF.FacturaID = F.ID
             INNER JOIN Producto P ON DF.ProductoID = P.ID
    WHERE F.ClienteID = @ClienteID
      AND DATEDIFF(DAY, F.FechaCreacion, GETDATE()) <= 7
      AND F.Estado = 'Pendiente'; -- ✅ Solo compras activas
END
go

