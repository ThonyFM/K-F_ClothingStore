
CREATE PROCEDURE sp_GetProveedor
    @ID INT
AS
BEGIN
    SELECT * FROM Proveedor WHERE ID = @ID;
END;
go

