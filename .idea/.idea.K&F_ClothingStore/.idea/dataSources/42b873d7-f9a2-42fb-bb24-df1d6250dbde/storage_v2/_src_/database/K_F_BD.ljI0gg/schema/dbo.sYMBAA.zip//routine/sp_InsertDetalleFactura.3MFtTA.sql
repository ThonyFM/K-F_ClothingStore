
CREATE PROCEDURE sp_InsertDetalleFactura
    @FacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @PrecioUnitario DECIMAL(10,2),
    @Subtotal DECIMAL(10,2),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO DetalleFactura (FacturaID, ProductoID, Cantidad, PrecioUnitario, Subtotal)
    VALUES (@FacturaID, @ProductoID, @Cantidad, @PrecioUnitario, @Subtotal);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

