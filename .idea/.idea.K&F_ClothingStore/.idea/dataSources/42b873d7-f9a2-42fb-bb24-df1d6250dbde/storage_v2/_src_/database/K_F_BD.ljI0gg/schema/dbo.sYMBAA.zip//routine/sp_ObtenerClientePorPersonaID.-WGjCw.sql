CREATE PROCEDURE sp_ObtenerClientePorPersonaID
@PersonaID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID,
        PersonaID,
        CodigoCliente,
        Estado,
        CreadoPor,
        FechaCreacion,
        FechaModificacion,
        ModificadoPor
    FROM Cliente
    WHERE PersonaID = @PersonaID;
END;
go

