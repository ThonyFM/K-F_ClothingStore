CREATE PROCEDURE InsertarUsuario
    @NombreUsuario VARCHAR(50),
    @ContrasenaHash VARCHAR(255),
    @Email VARCHAR(255),
    @Rol VARCHAR(50),
    @Estado VARCHAR(50)
AS
BEGIN
    INSERT INTO Usuario (NombreUsuario, ContrasenaHash, Email, Rol, Estado, FechaCreacion)
    VALUES (@NombreUsuario, @ContrasenaHash, @Email, @Rol, @Estado, GETDATE())
END
go

