CREATE PROCEDURE ObtenerUsuarios
AS
BEGIN
    SELECT ID, NombreUsuario, ContrasenaHash, Email, Rol, Estado, FechaCreacion, FechaModificacion
    FROM Usuario
END
go

