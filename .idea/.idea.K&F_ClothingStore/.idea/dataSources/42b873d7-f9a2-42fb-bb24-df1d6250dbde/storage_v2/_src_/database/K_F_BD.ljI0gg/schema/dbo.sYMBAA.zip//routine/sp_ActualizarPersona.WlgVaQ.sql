CREATE PROCEDURE sp_ActualizarPersona
    @PersonaID INT,
    @Nombre1 NVARCHAR(50),
    @Nombre2 NVARCHAR(50),
    @Apellido1 NVARCHAR(50),
    @Apellido2 NVARCHAR(50),
    @Telefono NVARCHAR(15),
    @Email NVARCHAR(255),
    @Genero NVARCHAR(50)
AS
BEGIN
    UPDATE Persona
    SET Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        Apellido1 = @Apellido1,
        Apellido2 = @Apellido2,
        Telefono = @Telefono,
        Email = @Email,
        Genero = @Genero,
        FechaModificacion = GETDATE()
    WHERE ID = @PersonaID;
END;
go

