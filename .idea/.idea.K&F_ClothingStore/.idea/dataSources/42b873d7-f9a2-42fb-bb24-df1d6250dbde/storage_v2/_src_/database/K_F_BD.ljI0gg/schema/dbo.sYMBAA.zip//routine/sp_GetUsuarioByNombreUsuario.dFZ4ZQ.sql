CREATE PROCEDURE sp_GetUsuarioByNombreUsuario
    @NombreUsuario NVARCHAR(50)
AS
BEGIN
    SELECT * FROM Usuario WHERE NombreUsuario = @NombreUsuario;
END
go

