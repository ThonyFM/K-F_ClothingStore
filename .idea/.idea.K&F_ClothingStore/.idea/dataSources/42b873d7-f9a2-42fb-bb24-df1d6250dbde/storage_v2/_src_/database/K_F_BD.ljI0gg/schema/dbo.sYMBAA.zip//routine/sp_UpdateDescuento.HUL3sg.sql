
CREATE PROCEDURE sp_UpdateDescuento
    @ID INT,
    @Tipo NVARCHAR(50),
    @Valor DECIMAL(10,2),
    @Descripcion NVARCHAR(255) = NULL,
    @FechaInicio DATETIME,
    @FechaFin DATETIME = NULL,
    @Estado NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Descuento
    SET Tipo = @Tipo, Valor = @Valor, Descripcion = @Descripcion, FechaInicio = @FechaInicio,
        FechaFin = @FechaFin, Estado = @Estado
    WHERE ID = @ID;
END
go

