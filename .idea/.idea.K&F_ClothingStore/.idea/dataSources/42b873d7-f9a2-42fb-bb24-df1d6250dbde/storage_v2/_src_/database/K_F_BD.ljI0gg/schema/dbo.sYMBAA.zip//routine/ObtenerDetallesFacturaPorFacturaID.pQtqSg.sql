CREATE PROCEDURE ObtenerDetallesFacturaPorFacturaID
@FacturaID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        DF.ID,
        DF.FacturaID,
        DF.ProductoID,
        
        DF.Cantidad,
        DF.PrecioUnitario,
        DF.Subtotal
    FROM DetalleFactura DF
             INNER JOIN Producto P ON DF.ProductoID = P.ID
    WHERE DF.FacturaID = @FacturaID;
END;
go

