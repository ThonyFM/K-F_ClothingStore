
CREATE PROCEDURE sp_InsertCliente
    @PersonaID INT,
    @CodigoCliente INT,
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Cliente (PersonaID, CodigoCliente, Estado, CreadoPor)
    VALUES (@PersonaID, @CodigoCliente, @Estado, @CreadoPor);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

