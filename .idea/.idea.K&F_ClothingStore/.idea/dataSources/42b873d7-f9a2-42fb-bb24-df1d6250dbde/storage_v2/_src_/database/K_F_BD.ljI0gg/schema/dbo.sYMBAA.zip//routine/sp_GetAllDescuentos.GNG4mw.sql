
CREATE PROCEDURE sp_GetAllDescuentos
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Descuento;
END
go

