
CREATE PROCEDURE sp_DeleteDetalleFactura
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM DetalleFactura WHERE ID = @ID;
END
go

