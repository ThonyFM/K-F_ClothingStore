-- Procedimiento para obtener el perfil completo de un usuario
CREATE PROCEDURE ObtenerPerfilCompleto
@ClienteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ID AS PersonaID, p.Nombre1, p.Nombre2, p.Apellido1, p.Apellido2,
        p.DocumentoIdentidad, p.Telefono, p.Email, p.FechaNacimiento, p.Genero,
        d.ID AS DireccionID, d.Ciudad, d.Estado, d.CodigoPostal, d.Pais, d.TipoDireccion,
        u.ID AS UsuarioID, u.NombreUsuario, u.Email AS UsuarioEmail, u.Rol, u.Estado
    FROM Persona p
             INNER JOIN Direccion d ON p.DireccionID = d.ID
             INNER JOIN Usuario u ON p.UsuarioID = u.ID
    WHERE p.ID = @ClienteID;
END;
go

