CREATE PROCEDURE ObtenerFacturas
AS
BEGIN
    SELECT
        ID,
        ClienteID,
        Total,
        MetodoPago,
        Estado,
        FechaCreacion,
        FechaModificacion,
        CreadoPor,
        ModificadoPor
    FROM Factura
END
go

