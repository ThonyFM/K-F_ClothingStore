



CREATE PROCEDURE sp_GetVentaById
    @VentaID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Venta WHERE VentaID = @VentaID;
END
go

