CREATE PROCEDURE sp_EliminarPerfilUsuario
@UsuarioID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM Usuario WHERE ID = @UsuarioID;

    -- Valor de retorno: 1 si eliminó algo, 0 si no encontró el usuario
    IF @@ROWCOUNT > 0
        RETURN 1;
    ELSE
        RETURN 0;
END;
go

