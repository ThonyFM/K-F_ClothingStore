
CREATE PROCEDURE sp_UpdateProveedor
    @ID INT,
    @NombreEmpresa NVARCHAR(100),
    @NombreContacto NVARCHAR(100),
    @Telefono NVARCHAR(15),
    @Email NVARCHAR(255),
    @DireccionID INT,
    @Estado NVARCHAR(50),
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    UPDATE Proveedor
    SET NombreEmpresa = @NombreEmpresa, NombreContacto = @NombreContacto, Telefono = @Telefono, 
        Email = @Email, DireccionID = @DireccionID, Estado = @Estado, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END;
go

