CREATE    PROCEDURE sp_AgregarDevolucion
    @FacturaID INT,
    @DetalleFacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Motivo NVARCHAR(255),
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Devolucion
    (
        FacturaID,
        DetalleFacturaID,
        ProductoID,
        Cantidad,
        Motivo,
        Estado,
        CreadoPor,
        FechaCreacion,
        FechaDevolucion
    )
    VALUES
        (
            @FacturaID,
            @DetalleFacturaID,
            @ProductoID,
            @Cantidad,
            @Motivo,
            @Estado,
            @CreadoPor,
            GETDATE(), -- Fecha de creación
            GETDATE()  -- Fecha de devolución
        );
END;
go

