CREATE PROCEDURE sp_AgregarAlCarrito
    @ClienteID INT,
    @ProductoID INT,
    @Cantidad INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar si el producto ya está en el carrito del cliente
    IF EXISTS (SELECT 1 FROM CarritoCompras WHERE ClienteID = @ClienteID AND ProductoID = @ProductoID)
        BEGIN
            -- Si ya existe, simplemente actualizar la cantidad
            UPDATE CarritoCompras
            SET Cantidad = Cantidad + @Cantidad,
                FechaModificacion = GETDATE()
            WHERE ClienteID = @ClienteID AND ProductoID = @ProductoID;
        END
    ELSE
        BEGIN
            -- Si no existe, insertar un nuevo registro
            INSERT INTO CarritoCompras (ClienteID, ProductoID, Cantidad, FechaAgregado)
            VALUES (@ClienteID, @ProductoID, @Cantidad, GETDATE());
        END
END;
go

