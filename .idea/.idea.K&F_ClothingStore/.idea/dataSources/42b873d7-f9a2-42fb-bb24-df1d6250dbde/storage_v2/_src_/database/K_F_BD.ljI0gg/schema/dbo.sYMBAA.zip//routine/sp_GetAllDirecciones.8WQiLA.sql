
CREATE PROCEDURE sp_GetAllDirecciones
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Direccion;
END
go

