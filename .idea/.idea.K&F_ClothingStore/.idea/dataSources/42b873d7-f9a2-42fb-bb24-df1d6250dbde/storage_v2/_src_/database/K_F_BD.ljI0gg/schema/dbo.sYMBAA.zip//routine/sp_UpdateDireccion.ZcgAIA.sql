
CREATE PROCEDURE sp_UpdateDireccion
    @ID INT,
    @Ciudad NVARCHAR(50),
    @Estado NVARCHAR(50),
    @CodigoPostal NVARCHAR(20),
    @Pais NVARCHAR(50),
    @TipoDireccion NVARCHAR(20) = NULL,
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Direccion
    SET Ciudad = @Ciudad, Estado = @Estado, CodigoPostal = @CodigoPostal, Pais = @Pais,
        TipoDireccion = @TipoDireccion, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

