
CREATE PROCEDURE sp_GetProducto
    @ID INT
AS
BEGIN
    SELECT * FROM Producto WHERE ID = @ID;
END;
go

