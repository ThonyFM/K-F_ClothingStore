
CREATE PROCEDURE sp_GetAllDetallesFactura
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM DetalleFactura;
END
go

