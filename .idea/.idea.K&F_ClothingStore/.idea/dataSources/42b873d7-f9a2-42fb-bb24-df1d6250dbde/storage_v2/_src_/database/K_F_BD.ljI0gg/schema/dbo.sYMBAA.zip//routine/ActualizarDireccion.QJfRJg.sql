CREATE PROCEDURE ActualizarDireccion
    @ID INT,
    @Ciudad VARCHAR(50),
    @Estado VARCHAR(50),
    @CodigoPostal VARCHAR(20),
    @Pais VARCHAR(50),
    @TipoDireccion VARCHAR(20),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Direccion
    SET Ciudad = @Ciudad,
        Estado = @Estado,
        CodigoPostal = @CodigoPostal,
        Pais = @Pais,
        TipoDireccion = @TipoDireccion,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

