
CREATE PROCEDURE sp_GetDevolucionById
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Devolucion WHERE ID = @ID;
END
go

