
CREATE PROCEDURE sp_UpdateCliente
    @ID INT,
    @CodigoCliente INT,
    @Estado NVARCHAR(50),
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Cliente
    SET CodigoCliente = @CodigoCliente, Estado = @Estado, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

