CREATE PROCEDURE ActualizarCliente
    @ID INT,
    @PersonaID INT,
    @CodigoCliente INT,
    @Estado VARCHAR(50),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Cliente
    SET PersonaID = @PersonaID,
        CodigoCliente = @CodigoCliente,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

