CREATE PROCEDURE ActualizarPersona
    @ID INT,
    @Nombre1 VARCHAR(50),
    @Nombre2 VARCHAR(50),
    @Apellido1 VARCHAR(50),
    @Apellido2 VARCHAR(50),
    @DocumentoIdentidad VARCHAR(20),
    @Telefono VARCHAR(15),
    @Email VARCHAR(255),
    @FechaNacimiento DATE,
    @Genero VARCHAR(50),
    @DireccionID INT,
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Persona
    SET Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        Apellido1 = @Apellido1,
        Apellido2 = @Apellido2,
        DocumentoIdentidad = @DocumentoIdentidad,
        Telefono = @Telefono,
        Email = @Email,
        FechaNacimiento = @FechaNacimiento,
        Genero = @Genero,
        DireccionID = @DireccionID,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

