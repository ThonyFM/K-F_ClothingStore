CREATE PROCEDURE InsertarCliente
    @PersonaID INT,
    @CodigoCliente INT,
    @Estado VARCHAR(50),
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Cliente (PersonaID, CodigoCliente, Estado, FechaCreacion, CreadoPor)
    VALUES (@PersonaID, @CodigoCliente, @Estado, GETDATE(), @CreadoPor)
END
go

