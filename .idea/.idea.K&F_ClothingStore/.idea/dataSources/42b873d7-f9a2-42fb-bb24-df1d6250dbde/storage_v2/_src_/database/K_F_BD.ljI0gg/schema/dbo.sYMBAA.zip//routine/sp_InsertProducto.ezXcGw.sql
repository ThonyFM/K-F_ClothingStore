CREATE PROCEDURE sp_InsertProducto
    @NombreProducto NVARCHAR(100),
    @Genero NVARCHAR(20),
    @SegmentoEdad NVARCHAR(50),
    @TipoProducto NVARCHAR(50),
    @Color NVARCHAR(30),
    @Talla NVARCHAR(20),
    @UnidadesDisponibles INT,
    @Precio DECIMAL(10,2),
    @Descripcion NVARCHAR(500)
AS
BEGIN
    INSERT INTO Producto (NombreProducto, Genero, SegmentoEdad, TipoProducto, Color, Talla, UnidadesDisponibles, Precio, Descripcion)
    VALUES (@NombreProducto, @Genero, @SegmentoEdad, @TipoProducto, @Color, @Talla, @UnidadesDisponibles, @Precio, @Descripcion);
END;
go

