CREATE PROCEDURE sp_ActualizarDevolucion
    @ID INT,
    @Cantidad INT,
    @Motivo NVARCHAR(255),
    @Estado NVARCHAR(50),
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    UPDATE Devolucion
    SET
        Cantidad = @Cantidad,
        Motivo = @Motivo,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

