create PROCEDURE sp_GetTodosLosProductos
AS
BEGIN
    SELECT
        ID,
        NombreProducto,
        Genero,
        SegmentoEdad,
        TipoProducto,
        Color,
        Talla,
        UnidadesDisponibles,
        Precio,
        Descripcion,
        ImagenUrl,  -- 🔹 Asegúrate de incluir esta columna
        FechaCreacion,
        FechaModificacion
    FROM Producto;
END;
go

