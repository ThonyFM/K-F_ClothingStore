CREATE PROCEDURE InsertarEmpleado
    @PersonaID INT,
    @Puesto VARCHAR(100),
    @FechaContratacion DATE,
    @Salario DECIMAL(18,2),
    @Estado VARCHAR(50),
    @CreadoPor VARCHAR(50)
AS
BEGIN
    INSERT INTO Empleado (PersonaID, Puesto, FechaContratacion, Salario, Estado, FechaCreacion, CreadoPor)
    VALUES (@PersonaID, @Puesto, @FechaContratacion, @Salario, @Estado, GETDATE(), @CreadoPor)
END
go

