
CREATE PROCEDURE sp_DeleteEmpleado
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar si el empleado ha realizado ventas o facturas
    IF EXISTS (SELECT 1 FROM Venta WHERE EmpleadoID = @ID) OR EXISTS (SELECT 1 FROM Factura WHERE EmpleadoID = @ID)
    BEGIN
        RAISERROR('No se puede eliminar el empleado porque tiene ventas o facturas asociadas.', 16, 1);
        RETURN;
    END

    DELETE FROM Empleado WHERE ID = @ID;
END
go

