
CREATE PROCEDURE sp_UpdateDetalleFactura
    @ID INT,
    @FacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @PrecioUnitario DECIMAL(10,2),
    @Subtotal DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE DetalleFactura
    SET FacturaID = @FacturaID, ProductoID = @ProductoID, Cantidad = @Cantidad,
        PrecioUnitario = @PrecioUnitario, Subtotal = @Subtotal
    WHERE ID = @ID;
END
go

