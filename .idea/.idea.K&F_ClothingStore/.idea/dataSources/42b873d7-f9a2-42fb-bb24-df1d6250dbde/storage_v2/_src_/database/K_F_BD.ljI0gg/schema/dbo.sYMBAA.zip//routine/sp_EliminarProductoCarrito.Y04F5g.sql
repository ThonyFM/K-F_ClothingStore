CREATE PROCEDURE sp_EliminarProductoCarrito
    @ClienteID INT,
    @ProductoID INT
AS
BEGIN
    -- Elimina el producto del carrito del cliente
    DELETE FROM CarritoCompras
    WHERE ClienteID = @ClienteID AND ProductoID = @ProductoID;
END
go

