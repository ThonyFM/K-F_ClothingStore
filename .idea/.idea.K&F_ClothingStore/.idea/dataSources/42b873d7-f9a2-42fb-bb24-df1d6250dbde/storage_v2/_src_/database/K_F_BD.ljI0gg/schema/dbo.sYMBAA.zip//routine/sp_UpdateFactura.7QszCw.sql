
CREATE PROCEDURE sp_UpdateFactura
    @ID INT,
    @ClienteID INT,
    @EmpleadoID INT,
    @Total DECIMAL(10,2),
    @MetodoPago NVARCHAR(50),
    @Estado NVARCHAR(50),
    @DescuentoID INT,
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    UPDATE Factura
    SET ClienteID = @ClienteID, EmpleadoID = @EmpleadoID, Total = @Total, MetodoPago = @MetodoPago, 
        Estado = @Estado, DescuentoID = @DescuentoID, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END;
go

