
CREATE PROCEDURE sp_UpdatePersona
    @ID INT,
    @Nombre1 NVARCHAR(50),
    @Nombre2 NVARCHAR(50) = NULL,
    @Apellido1 NVARCHAR(50),
    @Apellido2 NVARCHAR(50),
    @Telefono NVARCHAR(15) = NULL,
    @Email NVARCHAR(255) = NULL,
    @FechaNacimiento DATE = NULL,
    @Genero NVARCHAR(50) = NULL,
    @DireccionID INT,
    @ModificadoPor NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Persona
    SET Nombre1 = @Nombre1, Nombre2 = @Nombre2, Apellido1 = @Apellido1, Apellido2 = @Apellido2,
        Telefono = @Telefono, Email = @Email, FechaNacimiento = @FechaNacimiento,
        Genero = @Genero, DireccionID = @DireccionID, FechaModificacion = GETDATE(), ModificadoPor = @ModificadoPor
    WHERE ID = @ID;
END
go

