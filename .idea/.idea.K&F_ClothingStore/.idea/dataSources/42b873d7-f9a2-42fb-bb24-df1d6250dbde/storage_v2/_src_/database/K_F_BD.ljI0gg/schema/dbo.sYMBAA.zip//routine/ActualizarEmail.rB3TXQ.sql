-- Procedimiento para actualizar el email en la tabla Usuario y Persona
        CREATE PROCEDURE ActualizarEmail
            @ClienteID INT,
            @NuevoEmail NVARCHAR(255)
        AS
        BEGIN
            SET NOCOUNT ON;

            UPDATE Usuario
            SET Email = @NuevoEmail,
                FechaModificacion = GETDATE()
            WHERE ID = (SELECT UsuarioID FROM Persona WHERE ID = @ClienteID);

            UPDATE Persona
            SET Email = @NuevoEmail,
                FechaModificacion = GETDATE()
            WHERE ID = @ClienteID;
        END;
go

