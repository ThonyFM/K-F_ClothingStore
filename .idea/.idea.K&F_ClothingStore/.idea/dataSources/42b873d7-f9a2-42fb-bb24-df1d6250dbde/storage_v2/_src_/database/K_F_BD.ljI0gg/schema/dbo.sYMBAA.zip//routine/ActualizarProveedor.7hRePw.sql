CREATE PROCEDURE ActualizarProveedor
    @ID INT,
    @NombreEmpresa VARCHAR(100),
    @NombreContacto VARCHAR(100),
    @Telefono VARCHAR(15),
    @Email VARCHAR(255),
    @DireccionID INT,
    @Estado VARCHAR(50),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Proveedor
    SET NombreEmpresa = @NombreEmpresa,
        NombreContacto = @NombreContacto,
        Telefono = @Telefono,
        Email = @Email,
        DireccionID = @DireccionID,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

