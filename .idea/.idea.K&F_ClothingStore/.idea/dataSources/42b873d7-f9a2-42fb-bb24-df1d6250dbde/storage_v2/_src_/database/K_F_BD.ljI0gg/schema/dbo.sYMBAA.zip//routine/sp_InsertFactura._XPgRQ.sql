CREATE PROCEDURE sp_InsertFactura
    @ClienteID INT,
    @Total DECIMAL(10,2),
    @MetodoPago NVARCHAR(50),
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50),
    @FacturaID INT OUTPUT
AS
BEGIN
    INSERT INTO Factura (ClienteID,  Total, MetodoPago, Estado,  CreadoPor)
    VALUES (@ClienteID,  @Total, @MetodoPago, @Estado, @CreadoPor);
    SET @FacturaID = SCOPE_IDENTITY();
END;
go

