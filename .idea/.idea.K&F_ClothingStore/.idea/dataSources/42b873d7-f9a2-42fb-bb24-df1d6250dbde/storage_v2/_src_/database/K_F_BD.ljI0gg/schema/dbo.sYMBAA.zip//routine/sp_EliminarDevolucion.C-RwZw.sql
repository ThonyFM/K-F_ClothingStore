CREATE PROCEDURE sp_EliminarDevolucion
@ID INT
AS
BEGIN
    DELETE FROM Devolucion
    WHERE ID = @ID;
END
go

