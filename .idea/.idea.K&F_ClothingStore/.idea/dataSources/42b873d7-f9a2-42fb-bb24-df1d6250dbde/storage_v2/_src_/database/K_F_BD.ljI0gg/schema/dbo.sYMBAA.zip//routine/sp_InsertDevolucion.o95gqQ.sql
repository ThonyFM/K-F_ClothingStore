
CREATE PROCEDURE sp_InsertDevolucion
    @FacturaID INT,
    @DetalleFacturaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Motivo NVARCHAR(255),
    @Estado NVARCHAR(50),
    @CreadoPor NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Devolucion (FacturaID, DetalleFacturaID, ProductoID, Cantidad, Motivo, Estado, CreadoPor)
    VALUES (@FacturaID, @DetalleFacturaID, @ProductoID, @Cantidad, @Motivo, @Estado, @CreadoPor);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

