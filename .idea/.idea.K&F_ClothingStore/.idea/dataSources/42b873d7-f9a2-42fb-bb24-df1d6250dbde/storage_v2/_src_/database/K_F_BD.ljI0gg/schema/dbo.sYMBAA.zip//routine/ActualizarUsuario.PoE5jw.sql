CREATE PROCEDURE ActualizarUsuario
    @ID INT,
    @NombreUsuario VARCHAR(50),
    @ContrasenaHash VARCHAR(255),
    @Email VARCHAR(255),
    @Rol VARCHAR(50),
    @Estado VARCHAR(50)
AS
BEGIN
    UPDATE Usuario
    SET NombreUsuario = @NombreUsuario,
        ContrasenaHash = @ContrasenaHash,
        Email = @Email,
        Rol = @Rol,
        Estado = @Estado,
        FechaModificacion = GETDATE()
    WHERE ID = @ID
END
go

