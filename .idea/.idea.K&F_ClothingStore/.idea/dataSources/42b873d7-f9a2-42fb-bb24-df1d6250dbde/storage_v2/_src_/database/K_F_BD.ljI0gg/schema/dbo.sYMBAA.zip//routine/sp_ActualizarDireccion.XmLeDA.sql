CREATE PROCEDURE sp_ActualizarDireccion
    @DireccionID INT,
    @Ciudad NVARCHAR(50),
    @Estado NVARCHAR(50),
    @CodigoPostal NVARCHAR(20),
    @Pais NVARCHAR(50),
    @TipoDireccion NVARCHAR(20)
AS
BEGIN
    UPDATE Direccion
    SET Ciudad = @Ciudad,
        Estado = @Estado,
        CodigoPostal = @CodigoPostal,
        Pais = @Pais,
        TipoDireccion = @TipoDireccion,
        FechaModificacion = GETDATE()
    WHERE ID = @DireccionID;
END;
go

