
CREATE PROCEDURE sp_InsertPersona
    @Nombre1 NVARCHAR(50),
    @Nombre2 NVARCHAR(50) = NULL,
    @Apellido1 NVARCHAR(50),
    @Apellido2 NVARCHAR(50),
    @DocumentoIdentidad NVARCHAR(20),
    @Telefono NVARCHAR(15) = NULL,
    @Email NVARCHAR(255) = NULL,
    @FechaNacimiento DATE = NULL,
    @Genero NVARCHAR(50) = NULL,
    @DireccionID INT,
    @CreadoPor NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Persona (Nombre1, Nombre2, Apellido1, Apellido2, DocumentoIdentidad, Telefono, Email, FechaNacimiento, Genero, DireccionID, CreadoPor)
    VALUES (@Nombre1, @Nombre2, @Apellido1, @Apellido2, @DocumentoIdentidad, @Telefono, @Email, @FechaNacimiento, @Genero, @DireccionID, @CreadoPor);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

