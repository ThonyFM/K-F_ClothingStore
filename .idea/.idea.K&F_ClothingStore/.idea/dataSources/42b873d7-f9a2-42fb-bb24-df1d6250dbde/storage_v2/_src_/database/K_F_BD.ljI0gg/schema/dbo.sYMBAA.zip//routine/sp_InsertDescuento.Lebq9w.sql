
CREATE PROCEDURE sp_InsertDescuento
    @Tipo NVARCHAR(50),
    @Valor DECIMAL(10,2),
    @Descripcion NVARCHAR(255) = NULL,
    @FechaInicio DATETIME,
    @FechaFin DATETIME = NULL,
    @Estado NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Descuento (Tipo, Valor, Descripcion, FechaInicio, FechaFin, Estado)
    VALUES (@Tipo, @Valor, @Descripcion, @FechaInicio, @FechaFin, @Estado);
    
    SET @NewID = SCOPE_IDENTITY();
END
go

