CREATE PROCEDURE BuscarPersonaPorCedula
@DocumentoIdentidad NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ID,
        p.Nombre1,
        p.Nombre2,
        p.Apellido1,
        p.Apellido2,
        p.DocumentoIdentidad,
        p.Telefono,
        p.Email,
        p.FechaNacimiento,
        p.Genero,
        p.DireccionID,
        d.Ciudad,
        d.Estado,
        d.CodigoPostal,
        d.Pais,
        d.TipoDireccion
    FROM Persona p
             INNER JOIN Direccion d ON p.DireccionID = d.ID
    WHERE p.DocumentoIdentidad = @DocumentoIdentidad;
END;
go

