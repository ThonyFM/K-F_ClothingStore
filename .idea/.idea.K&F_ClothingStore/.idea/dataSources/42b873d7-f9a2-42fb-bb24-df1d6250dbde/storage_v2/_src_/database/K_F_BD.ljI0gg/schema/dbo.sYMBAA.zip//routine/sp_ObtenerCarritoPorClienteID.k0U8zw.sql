CREATE PROCEDURE sp_ObtenerCarritoPorClienteID
@ClienteID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        C.ID AS CarritoID,
        C.ClienteID,
        C.ProductoID,
        P.NombreProducto,
        P.Genero,
        P.SegmentoEdad,
        P.TipoProducto,
        P.Color,
        P.Talla,
        P.Precio,
        P.ImagenUrl,
        P.Descripcion,
        C.Cantidad,
        C.FechaAgregado,
        C.FechaModificacion
    FROM CarritoCompras C
             INNER JOIN Producto P ON C.ProductoID = P.ID
    WHERE C.ClienteID = @ClienteID;
END;
go

