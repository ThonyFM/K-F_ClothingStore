




CREATE PROCEDURE sp_GetProveedorById
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Proveedor WHERE ID = @ID;
END
go

