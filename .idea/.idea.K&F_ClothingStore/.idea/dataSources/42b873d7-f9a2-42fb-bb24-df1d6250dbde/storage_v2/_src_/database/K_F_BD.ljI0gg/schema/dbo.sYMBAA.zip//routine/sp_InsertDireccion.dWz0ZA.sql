CREATE PROCEDURE sp_InsertDireccion
    @Ciudad NVARCHAR(50),
    @Estado NVARCHAR(50),
    @CodigoPostal NVARCHAR(20),
    @Pais NVARCHAR(50),
    @TipoDireccion NVARCHAR(20) = NULL,
    @CreadoPor NVARCHAR(50),
    @NewID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        INSERT INTO Direccion (Ciudad, Estado, CodigoPostal, Pais, TipoDireccion, CreadoPor)
        VALUES (@Ciudad, @Estado, @CodigoPostal, @Pais, @TipoDireccion, @CreadoPor);

        SET @NewID = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END
go

