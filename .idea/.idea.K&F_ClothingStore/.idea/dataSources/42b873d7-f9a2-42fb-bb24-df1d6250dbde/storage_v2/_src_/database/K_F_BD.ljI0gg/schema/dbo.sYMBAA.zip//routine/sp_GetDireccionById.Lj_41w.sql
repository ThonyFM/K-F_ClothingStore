CREATE PROCEDURE sp_GetDireccionById
@ID INT
AS
BEGIN
    SELECT
        ID,
        Ciudad,
        Estado,
        CodigoPostal,
        Pais,
        TipoDireccion,
        FechaCreacion,
        CreadoPor,
        FechaModificacion,
        ModificadoPor
    FROM Direccion
    WHERE ID = @ID;
END
go

