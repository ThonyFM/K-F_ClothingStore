CREATE PROCEDURE ObtenerVentas
AS
BEGIN
    SELECT VentaID, EmpleadoID, ClienteID, ProductoID, Cantidad, Total, Fecha
    FROM Venta
END
go

