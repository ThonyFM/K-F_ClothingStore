CREATE PROCEDURE sp_EliminarUsuarioCompleto
@IdUsuario INT
AS
BEGIN
    DECLARE @PersonaID INT, @DireccionID INT;

    SELECT @PersonaID = ID, @DireccionID = DireccionID
    FROM Persona
    WHERE UsuarioID = @IdUsuario;

    DELETE FROM Cliente WHERE PersonaID = @PersonaID;
    DELETE FROM Persona WHERE ID = @PersonaID;
    DELETE FROM Usuario WHERE Id = @IdUsuario;
    DELETE FROM Direccion WHERE ID = @DireccionID;
END;
go

