CREATE PROCEDURE sp_GetCarritoPorClienteYProducto
    @ClienteID INT,
    @ProductoID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID,
        ClienteID,
        ProductoID,
        Cantidad,
        FechaAgregado,
        FechaModificacion
    FROM CarritoCompras
    WHERE ClienteID = @ClienteID AND ProductoID = @ProductoID;
END;
go

