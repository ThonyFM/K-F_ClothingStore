CREATE PROCEDURE sp_DeleteCliente
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar si el cliente tiene ventas o facturas
    IF EXISTS (SELECT 1 FROM Venta WHERE ClienteID = @ID) OR EXISTS (SELECT 1 FROM Factura WHERE ClienteID = @ID)
    BEGIN
        RAISERROR('No se puede eliminar el cliente porque tiene ventas o facturas asociadas.', 16, 1);
        RETURN;
    END

    DELETE FROM Cliente WHERE ID = @ID;
END
go

