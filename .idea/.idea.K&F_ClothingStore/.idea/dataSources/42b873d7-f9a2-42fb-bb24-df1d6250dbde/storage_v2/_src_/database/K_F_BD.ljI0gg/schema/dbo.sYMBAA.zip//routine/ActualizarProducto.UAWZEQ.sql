CREATE PROCEDURE ActualizarProducto
    @ID INT,
    @NombreProducto VARCHAR(100),
    @Genero VARCHAR(20),
    @SegmentoEdad VARCHAR(50),
    @TipoProducto VARCHAR(50),
    @Color VARCHAR(30),
    @Talla VARCHAR(20),
    @UnidadesDisponibles INT,
    @Precio DECIMAL(18,2),
    @ImagenUrl NVARCHAR(MAX),
    @Descripcion VARCHAR(500)
AS
BEGIN
    UPDATE Producto
    SET NombreProducto = @NombreProducto,
        Genero = @Genero,
        SegmentoEdad = @SegmentoEdad,
        TipoProducto = @TipoProducto,
        Color = @Color,
        Talla = @Talla,
        UnidadesDisponibles = @UnidadesDisponibles,
        Precio = @Precio,
        ImagenUrl = @ImagenUrl,
        Descripcion = @Descripcion,
        FechaModificacion = GETDATE()
    WHERE ID = @ID
END
go

