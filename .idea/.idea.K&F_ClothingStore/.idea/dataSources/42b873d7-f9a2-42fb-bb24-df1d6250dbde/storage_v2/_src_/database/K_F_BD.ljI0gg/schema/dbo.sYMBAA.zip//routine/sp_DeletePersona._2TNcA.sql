
CREATE PROCEDURE sp_DeletePersona
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar si la persona es un cliente o empleado
    IF EXISTS (SELECT 1 FROM Cliente WHERE PersonaID = @ID) OR EXISTS (SELECT 1 FROM Empleado WHERE PersonaID = @ID)
    BEGIN
        RAISERROR('No se puede eliminar la persona porque está asociada a un cliente o empleado.', 16, 1);
        RETURN;
    END

    DELETE FROM Persona WHERE ID = @ID;
END
go

