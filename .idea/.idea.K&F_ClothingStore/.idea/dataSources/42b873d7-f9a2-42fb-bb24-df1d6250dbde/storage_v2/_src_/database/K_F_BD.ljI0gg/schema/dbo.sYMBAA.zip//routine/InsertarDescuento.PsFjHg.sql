CREATE PROCEDURE InsertarDescuento
    @Tipo VARCHAR(50),
    @Valor DECIMAL(18,2),
    @Descripcion VARCHAR(255),
    @FechaInicio DATE,
    @FechaFin DATE,
    @Estado VARCHAR(50)
AS
BEGIN
    INSERT INTO Descuento (Tipo, Valor, Descripcion, FechaInicio, FechaFin, Estado)
    VALUES (@Tipo, @Valor, @Descripcion, @FechaInicio, @FechaFin, @Estado)
END
go

