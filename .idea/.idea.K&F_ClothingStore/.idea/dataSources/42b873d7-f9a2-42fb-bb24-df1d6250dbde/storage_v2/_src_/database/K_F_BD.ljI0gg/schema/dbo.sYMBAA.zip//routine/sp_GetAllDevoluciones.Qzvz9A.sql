
CREATE PROCEDURE sp_GetAllDevoluciones
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM Devolucion;
END
go

