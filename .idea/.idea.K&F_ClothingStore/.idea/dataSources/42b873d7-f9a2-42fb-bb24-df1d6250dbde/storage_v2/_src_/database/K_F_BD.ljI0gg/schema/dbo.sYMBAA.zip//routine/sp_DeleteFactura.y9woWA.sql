
CREATE PROCEDURE sp_DeleteFactura
    @ID INT
AS
BEGIN
    DELETE FROM Factura WHERE ID = @ID;
END;
go

