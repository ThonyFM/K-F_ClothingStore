CREATE PROCEDURE ActualizarEmpleado
    @ID INT,
    @PersonaID INT,
    @Puesto VARCHAR(100),
    @FechaContratacion DATE,
    @Salario DECIMAL(18,2),
    @Estado VARCHAR(50),
    @ModificadoPor VARCHAR(50)
AS
BEGIN
    UPDATE Empleado
    SET PersonaID = @PersonaID,
        Puesto = @Puesto,
        FechaContratacion = @FechaContratacion,
        Salario = @Salario,
        Estado = @Estado,
        FechaModificacion = GETDATE(),
        ModificadoPor = @ModificadoPor
    WHERE ID = @ID
END
go

