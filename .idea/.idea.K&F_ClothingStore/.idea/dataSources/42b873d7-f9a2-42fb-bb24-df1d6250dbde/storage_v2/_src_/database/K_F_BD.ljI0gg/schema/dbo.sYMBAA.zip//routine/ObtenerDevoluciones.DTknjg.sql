CREATE PROCEDURE ObtenerDevoluciones
AS
BEGIN
    SELECT ID, FacturaID, DetalleFacturaID, ProductoID, Cantidad, Motivo, FechaDevolucion, Estado, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Devolucion
END
go

