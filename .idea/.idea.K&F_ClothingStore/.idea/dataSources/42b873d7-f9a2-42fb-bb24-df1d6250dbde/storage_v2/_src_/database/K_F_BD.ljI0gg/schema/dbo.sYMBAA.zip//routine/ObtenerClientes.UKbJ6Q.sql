CREATE PROCEDURE ObtenerClientes
AS
BEGIN
    SELECT ID, PersonaID, CodigoCliente, Estado, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Cliente
END
go

