
CREATE PROCEDURE sp_DeleteProducto
    @ID INT
AS
BEGIN
    DELETE FROM Producto WHERE ID = @ID;
END;
go

