CREATE PROCEDURE ActualizarDescuento
    @ID INT,
    @Tipo VARCHAR(50),
    @Valor DECIMAL(18,2),
    @Descripcion VARCHAR(255),
    @FechaInicio DATE,
    @FechaFin DATE,
    @Estado VARCHAR(50)
AS
BEGIN
    UPDATE Descuento
    SET Tipo = @Tipo,
        Valor = @Valor,
        Descripcion = @Descripcion,
        FechaInicio = @FechaInicio,
        FechaFin = @FechaFin,
        Estado = @Estado
    WHERE ID = @ID
END
go

