CREATE PROCEDURE sp_ObtenerUsuarioPorEmail
@Email NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID,
        NombreUsuario,
        ContrasenaHash,
        Email,
        Rol,
        Estado,
        FechaCreacion,
        FechaModificacion
    FROM Usuario
    WHERE Email = @Email;
END;
go

