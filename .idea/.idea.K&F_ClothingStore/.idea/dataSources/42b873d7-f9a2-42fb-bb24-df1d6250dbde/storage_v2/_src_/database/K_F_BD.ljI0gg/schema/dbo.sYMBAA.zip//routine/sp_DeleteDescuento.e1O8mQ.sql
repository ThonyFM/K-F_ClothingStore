
CREATE PROCEDURE sp_DeleteDescuento
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM Descuento WHERE ID = @ID;
END
go

