CREATE PROCEDURE ObtenerDescuentos
AS
BEGIN
    SELECT ID, Tipo, Valor, Descripcion, FechaInicio, FechaFin, Estado
    FROM Descuento
END
go

