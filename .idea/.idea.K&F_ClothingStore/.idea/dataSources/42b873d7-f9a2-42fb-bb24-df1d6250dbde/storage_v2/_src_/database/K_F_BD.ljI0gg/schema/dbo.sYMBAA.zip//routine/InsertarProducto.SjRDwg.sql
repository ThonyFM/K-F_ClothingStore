CREATE PROCEDURE InsertarProducto
    @NombreProducto VARCHAR(100),
    @Genero VARCHAR(20),
    @SegmentoEdad VARCHAR(50),
    @TipoProducto VARCHAR(50),
    @Color VARCHAR(30),
    @Talla VARCHAR(20),
    @UnidadesDisponibles INT,
    @Precio DECIMAL(18,2),
    @ImagenUrl NVARCHAR(MAX),
    @Descripcion VARCHAR(500)
AS
BEGIN
    INSERT INTO Producto (NombreProducto, Genero, SegmentoEdad, TipoProducto, Color, Talla, UnidadesDisponibles, Precio, ImagenUrl, Descripcion, FechaCreacion)
    VALUES (@NombreProducto, @Genero, @SegmentoEdad, @TipoProducto, @Color, @Talla, @UnidadesDisponibles, @Precio, @ImagenUrl, @Descripcion, GETDATE())
END
go

