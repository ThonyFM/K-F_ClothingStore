CREATE PROCEDURE ActualizarVenta
    @VentaID INT,
    @EmpleadoID INT,
    @ClienteID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Total DECIMAL(18,2)
AS
BEGIN
    UPDATE Venta
    SET EmpleadoID = @EmpleadoID,
        ClienteID = @ClienteID,
        ProductoID = @ProductoID,
        Cantidad = @Cantidad,
        Total = @Total,
        Fecha = GETDATE()
    WHERE VentaID = @VentaID
END
go

