CREATE PROCEDURE InsertarVenta
    @EmpleadoID INT,
    @ClienteID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Total DECIMAL(18,2)
AS
BEGIN
    INSERT INTO Venta (EmpleadoID, ClienteID, ProductoID, Cantidad, Total, Fecha)
    VALUES (@EmpleadoID, @ClienteID, @ProductoID, @Cantidad, @Total, GETDATE())
END
go

