CREATE   PROCEDURE sp_EliminarUsuario
@IdUsuario INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Email NVARCHAR(255), @PersonaID INT, @DireccionID INT;

    SELECT @Email = Email FROM Usuario WHERE ID = @IdUsuario;

    SELECT @PersonaID = ID, @DireccionID = DireccionID
    FROM Persona
    WHERE Email = @Email;

    DELETE FROM Cliente WHERE PersonaID = @PersonaID;
    DELETE FROM Persona WHERE ID = @PersonaID;
    DELETE FROM Direccion WHERE ID = @DireccionID;
    DELETE FROM Usuario WHERE ID = @IdUsuario;
END
go

