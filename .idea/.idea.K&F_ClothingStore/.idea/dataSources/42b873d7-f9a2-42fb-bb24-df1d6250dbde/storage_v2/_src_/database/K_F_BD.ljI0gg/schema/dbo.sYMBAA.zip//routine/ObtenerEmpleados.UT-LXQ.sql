CREATE PROCEDURE ObtenerEmpleados
AS
BEGIN
    SELECT ID, PersonaID, Puesto, FechaContratacion, Salario, Estado, FechaCreacion, FechaModificacion, CreadoPor, ModificadoPor
    FROM Empleado
END
go

