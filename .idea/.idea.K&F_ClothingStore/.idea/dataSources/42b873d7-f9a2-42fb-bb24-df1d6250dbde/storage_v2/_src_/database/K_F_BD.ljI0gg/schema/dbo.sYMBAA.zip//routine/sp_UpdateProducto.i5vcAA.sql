
CREATE PROCEDURE sp_UpdateProducto
    @ID INT,
    @NombreProducto NVARCHAR(100),
    @Genero NVARCHAR(20),
    @SegmentoEdad NVARCHAR(50),
    @TipoProducto NVARCHAR(50),
    @Color NVARCHAR(30),
    @Talla NVARCHAR(20),
    @UnidadesDisponibles INT,
    @Precio DECIMAL(10,2),
    @Descripcion NVARCHAR(500)
AS
BEGIN
    UPDATE Producto
    SET NombreProducto = @NombreProducto, Genero = @Genero, SegmentoEdad = @SegmentoEdad, TipoProducto = @TipoProducto, 
        Color = @Color, Talla = @Talla, UnidadesDisponibles = @UnidadesDisponibles, Precio = @Precio, Descripcion = @Descripcion
    WHERE ID = @ID;
END;
go

