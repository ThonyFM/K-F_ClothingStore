
CREATE PROCEDURE sp_GetDetalleFacturaById
    @ID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM DetalleFactura WHERE ID = @ID;
END
go

